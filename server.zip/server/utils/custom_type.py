# from bson import ObjectId
# from pydantic import GetJsonSchemaHandler
# from pydantic.json_schema import JsonSchemaValue
# from pydantic_core import core_schema
# from typing import Any

# class PyObjectId(ObjectId):
#     @classmethod
#     def __get_pydantic_core_schema__(
#         cls, source_type: Any, handler: Any
#     ) -> core_schema.CoreSchema:
#         return core_schema.no_info_wrap_validator_function(
#             cls.validate,
#             core_schema.str_schema(),
#             serialization=core_schema.to_string_ser_schema(),
#         )

#     @classmethod
#     def __get_pydantic_json_schema__(
#         cls, schema: core_schema.CoreSchema, handler: GetJsonSchemaHandler
#     ) -> JsonSchemaValue:
#         return {"type": "string", "format": "objectid"}

#     @classmethod
#     def validate(cls, v):
#         if isinstance(v, ObjectId):
#             return v
#         if isinstance(v, str) and ObjectId.is_valid(v):
#             return ObjectId(v)
#         raise ValueError("Invalid ObjectId")

from bson import ObjectId
from pydantic import GetJsonSchemaHandler
from pydantic.json_schema import JsonSchemaValue
from pydantic_core import core_schema
from typing import Any

class PyObjectId(ObjectId):
    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: Any
    ) -> core_schema.CoreSchema:
        return core_schema.no_info_wrap_validator_function(
            cls.validate,
            core_schema.str_schema(),
            serialization=core_schema.to_string_ser_schema(),
        )

    @classmethod
    def __get_pydantic_json_schema__(
        cls, schema: core_schema.CoreSchema, handler: GetJsonSchemaHandler
    ) -> JsonSchemaValue:
        return {"type": "string", "format": "objectid"}

    @classmethod
    def validate(cls, v, _info):  # <-- Only one argument!
        if isinstance(v, ObjectId):
            return v
        if isinstance(v, str) and ObjectId.is_valid(v):
            return ObjectId(v)
        raise ValueError("Invalid ObjectId")