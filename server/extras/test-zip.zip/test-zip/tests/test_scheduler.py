import unittest
from scheduler import Scheduler, Task
from datetime import datetime, timedelta

class TestScheduler(unittest.TestCase):
    def test_add_and_run_task(self):
        results = []
        def sample():
            results.append('ran')
        sched = Scheduler()
        run_at = datetime.now() + timedelta(seconds=1)
        task = Task(sample, run_at=run_at)
        sched.add_task(task)
        import threading
        t = threading.Thread(target=lambda: sched.start(poll_interval=0.5))
        t.start()
        import time; time.sleep(2)
        sched.stop()
        t.join()
        self.assertIn('ran', results)

if __name__ == "__main__":
    unittest.main()
