import unittest
from scheduler import TaskQueue, Task

class TestTaskQueue(unittest.TestCase):
    def test_add_and_remove(self):
        def dummy(): pass
        task = Task(dummy)
        queue = TaskQueue()
        queue.add_task(task)
        self.assertIn(task, queue.tasks)
        queue.remove_task(task)
        self.assertNotIn(task, queue.tasks)

if __name__ == "__main__":
    unittest.main()
