import unittest
from scheduler import Task

class TestTask(unittest.TestCase):
    def test_should_run(self):
        def dummy(): pass
        from datetime import datetime, timedelta
        run_at = datetime.now() - timedelta(seconds=1)
        task = Task(dummy, run_at=run_at)
        self.assertTrue(task.should_run())

if __name__ == "__main__":
    unittest.main()
