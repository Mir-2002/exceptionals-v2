# Example: Simple one-off task
from scheduler import Scheduler, Task
from datetime import datetime, timedelta

def hello():
    print("Hello, world!")

if __name__ == "__main__":
    sched = Scheduler()
    run_at = datetime.now() + timedelta(seconds=2)
    task = Task(hello, run_at=run_at)
    sched.add_task(task)
    sched.start(poll_interval=1)
