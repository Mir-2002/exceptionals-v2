# Init for examples
