# Example: Recurring task
from scheduler import Scheduler, Task

def tick():
    print("Tick!")

if __name__ == "__main__":
    sched = Scheduler()
    task = Task(tick, interval=3, repeat=True)
    sched.add_task(task)
    sched.start(poll_interval=1)
