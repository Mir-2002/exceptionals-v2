# Lightweight Python Task Scheduling Framework

A minimal framework for scheduling and running tasks, supporting one-off and recurring jobs.

## Structure

- scheduler/: Core framework modules
- examples/: Usage examples
- tests/: Unit tests

## Usage

See `examples/` for sample tasks and scheduling.
