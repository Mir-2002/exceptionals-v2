class TaskQueue:
    def __init__(self):
        self.tasks = []

    def add_task(self, task):
        self.tasks.append(task)

    def get_ready_tasks(self):
        return [t for t in self.tasks if t.should_run()]

    def remove_task(self, task):
        self.tasks.remove(task)
