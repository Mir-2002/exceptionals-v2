from .base import BaseScheduler
from .queue import TaskQueue
from .logger import get_logger
from .exceptions import SchedulerError
from .utils import sleep

class Scheduler(BaseScheduler):
    def __init__(self):
        self.queue = TaskQueue()
        self.logger = get_logger()
        self.running = False

    def add_task(self, task):
        self.queue.add_task(task)
        self.logger.info(f"Task '{task.name}' added.")

    def start(self, poll_interval=1):
        self.running = True
        self.logger.info("Scheduler started.")
        try:
            while self.running:
                ready_tasks = self.queue.get_ready_tasks()
                for task in ready_tasks:
                    try:
                        task.run()
                        self.logger.info(f"Task '{task.name}' executed.")
                        if not task.repeat:
                            self.queue.remove_task(task)
                    except Exception as e:
                        self.logger.error(str(e))
                sleep(poll_interval)
        except Exception as e:
            raise SchedulerError(f"Scheduler failed: {e}")

    def stop(self):
        self.running = False
        self.logger.info("Scheduler stopped.")
