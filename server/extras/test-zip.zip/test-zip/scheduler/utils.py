import time
from datetime import datetime, timedelta

def now():
    return datetime.now()

def sleep(seconds):
    time.sleep(seconds)
