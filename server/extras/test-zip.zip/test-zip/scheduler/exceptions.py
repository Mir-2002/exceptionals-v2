class TaskError(Exception):
    pass

class SchedulerError(Exception):
    pass
