class BaseTask:
    def run(self):
        raise NotImplementedError

class BaseScheduler:
    def start(self):
        raise NotImplementedError
