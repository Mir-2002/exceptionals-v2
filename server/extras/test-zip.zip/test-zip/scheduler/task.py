from .base import BaseTask
from .exceptions import TaskError

class Task(BaseTask):
    def __init__(self, func, name=None, interval=None, run_at=None, repeat=False):
        self.func = func
        self.name = name or func.__name__
        self.interval = interval
        self.run_at = run_at
        self.repeat = repeat
        self.last_run = None

    def should_run(self):
        from .utils import now
        if self.run_at and (self.last_run is None):
            return now() >= self.run_at
        if self.interval and self.last_run:
            return (now() - self.last_run).total_seconds() >= self.interval
        return self.last_run is None

    def run(self):
        try:
            self.func()
            self.last_run = __import__('datetime').datetime.now()
        except Exception as e:
            raise TaskError(f"Task '{self.name}' failed: {e}")
